import SwiftUI


///Basic model for the playground. this is the data for the rows. 
///- For use with `List` and `ForEach`, it adopts `Identifiable`
struct ModelItem:Identifiable{
    var id:Int
    var item:String
    var quantity:Int
    var unitPrice:Double
    var lineTotal:Double{
        Double(quantity) * unitPrice
    }
}

///The main model for this project
/// - demonstrates some functional programming techniques.
class BeautyModel{
    var beautyItems:[ModelItem] = [
        ModelItem(id:3,item:"Muck Rake",quantity: 43,unitPrice: 12.95),
        ModelItem(id:4,item:"Buzz Cut",quantity: 15,unitPrice: 6.75),
        ModelItem(id:5,item:"Toe Toner",quantity: 250,unitPrice: 49.95),
        ModelItem(id:6,item:"Eye Snuff",quantity: 2,unitPrice: 4.95)
    ]
    func subtotal()-> Double{
        let prices = beautyItems.map{$0.lineTotal}
        return prices.reduce(0.0,+)
        
    }
    func tax(taxPercent:Double)-> Double{
        return (taxPercent/100) * subtotal()
    }
    func total(taxPercent:Double)->Double{
        return tax(taxPercent:taxPercent) + subtotal()
    }
}

///A view for a left justified text field
/// - Parameter string: the string to show
/// - Parameter width: width of the view. defaults to 100
struct LeftText:View{
    var string:String
    var width:CGFloat = 100
    var body: some View{
            VStack{
                HStack{
                    Text(string)
                    Spacer()
                }.frame(width:width)
                Divider()
            }
        }
}


struct TotalView:View{
    var title:String
    var number:Double
    var body: some View{
        VStack{
            HStack{
                LeftText(string: title, width: 550)
                
                RightText(number:number, width:200)
                Spacer()
            }
        }
    }
}

///A view for a right justified curency or integer
/// - Parameter number: the string to show
///
/// - Parameter width: width of the view. defaults to 100
struct RightText:View{
    var number:Double
    var nodecimals:Bool = false
    var width:CGFloat = 100
    var numberString:String{
        if nodecimals{
            return NumberFormatter.localizedString(from: NSNumber(value:number), number: .decimal)
        }
        return NumberFormatter.localizedString(from: NSNumber(value:number), number: .currency)
    }
    var body: some View{
        HStack{
            Spacer()
            Text(numberString)
            Divider().frame(height:50)
        }.frame(width:width)
    }
}

struct VisiView:View{
    let gradient = LinearGradient(gradient: Gradient(colors:[
        Color(hue:0.85, saturation: 0.3, brightness: 1.0 ),Color(hue:0.80, saturation: 0.1, brightness: 0.9 )
    ]), startPoint: .top, endPoint: .bottom)
    var beautyModel = BeautyModel()
    var body: some View{
        VStack{
            Text("BeautyStuff Daily Accounting")
                .font(.largeTitle)
                .padding([.leading,.trailing], 100)
            .padding(.bottom)
                .background(Color(hue:0.80, saturation: 0.1, brightness: 0.9 ))
                .cornerRadius(10)
            HStack{
                LeftText(string:"Item",width: 300)
                LeftText(string:"No.")
                LeftText(string:"Unit",width:150)
                LeftText(string:"Cost",width:200)
                Spacer()
            }.font(.headline)
            ForEach(beautyModel.beautyItems){i in
                HStack{
                    LeftText(string:i.item,width: 300)
                    RightText(number: Double(i.quantity),nodecimals: true)
                    RightText(number:i.unitPrice,width:150)
                    RightText(number:i.lineTotal,width:200)
                    Spacer()
                }.font(.title)
            }
            Divider()
            VStack{
                TotalView(title: "Subtotal", number: beautyModel.subtotal())
                TotalView(title: "Taxes", number: beautyModel.tax(taxPercent: 9.75))
                TotalView(title: "Subtotal", number: beautyModel.total(taxPercent: 9.75))
            }
            .font(.title)
            .padding()
            .background(gradient)
            .cornerRadius(10)
            Spacer()
        }.padding()
    }
    
}
    
import PlaygroundSupport
PlaygroundPage.current.setLiveView(VisiView())




